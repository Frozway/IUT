#include <iostream>
#include "color.h"
#include "typeDef.h"
#include "tests.h"
#include "functions.h"

using namespace std;

int main()
{
    /*
    test_push() ;
    test_top() ;
    test_pop() ;
    test_insert() ;
    test_displayList();
    test_remove() ;
    test_min() ;
    test_putACard() ;
    test_shuffle() ;
    test_moveUp() ;
    test_moveDown();
    test_play() ;
    test_isValid();
    */

//******************** Boucle de jeu **************************//

    int choice ;

    displayTitle() ;

    cout << R"(
            //==========================================================\\

                          /-----------------------------\
                          |       TheGame - Menu        |
                          |-----------------------------|
                          |                             |
                          | [1] : Solo Mode             |
                          |                             |
                          | [2] : Multijoueur           |
                          |                             |
                          | [3] : Tests du code         |
                          |                             |
                          | [4] : Regles du jeu         |
                          |                             |
                          | [5] : Quitter le jeu        |
                          |                             |
                          \-----------------------------/

            \\==========================================================//

                            Quel est votre choix : )";

    //cout << BLUE_TEXT << "Quel est votre choix : " << COLOR_RESET ;
    cin >> choice ;
    cout << endl ;

    if ( (choice < 1) || (choice > 4) )
    {
        do
        {
            cout << endl << RED_TEXT << "Votre choix n'est pas possible, veuillez recommencer : " << COLOR_RESET;
            cin >> choice ;
        }
        while ( (choice < 1) || (choice > 4) ) ;


    }


    switch(choice)
    {
        case 1 : soloMode();
        break;

        case 2 : multiMode();
        break;

        case 3 : launchTest();
        break;

        case 4 : cout << "En cours de developpement";

        case 5 : break ;

        break;
    }

    return 0;
}
