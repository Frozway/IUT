-- ==========================
-- fichier : presentation_surgeles.sql
-- base : presentation
-- auteur(s) : Demouge Colin
-- date : 11/10/2022
-- role : Créer les tables
-- projet : Client
-- resultat dans : 
-- ==========================

column NOMCLI format a10 ;
column PRENOMCLI format a10 ;
column TELCLI format a10 ; 
column MAILCLI format a15 ;
column ADRCLI format a15 ; 