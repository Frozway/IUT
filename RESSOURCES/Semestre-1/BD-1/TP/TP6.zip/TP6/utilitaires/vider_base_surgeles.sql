-- ==========================
-- fichier : delete.sql
-- base : presentation
-- auteur(s) : LEFRANCOIS Thibaut
-- date : 21/10/2022
-- role : Remettre à 0 lmd
-- projet : Client
-- resultat dans : 
-- ==========================

DELETE FROM LIGNE_COMMANDE;
DELETE FROM LIVREUR;
DELETE FROM LIVRAISON;
DELETE FROM COMMANDE;
DELETE FROM PRODUIT;
DELETE FROM CLIENT;
