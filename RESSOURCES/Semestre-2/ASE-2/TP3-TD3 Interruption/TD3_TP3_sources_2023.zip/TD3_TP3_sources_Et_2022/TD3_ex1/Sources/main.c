/**
  ******************************************************************************
  * @file    main.c 

  ******************************************************************************/

/* Includes ------------------------------------------------------------------*/
#include "stm32f10x.h"           // STM32F10x Library Definitions

#define UIE (1<<0)
#define UIF (1<<0)
#define CEN (1<<0)
#define LEDS_PORTB   GPIOB->ODR

#define SETENA0 *(volatile unsigned long *)0xE000E100
#define TIM1_UP_IRQChannel (1<<25)

void Enable_GPIO(void)
{
	RCC->APB2ENR |= (1 << 3); // Enable GPIOB clock
	
}
  
void Init_GPIO(void)
{
	GPIOB->CRH = 0x33333333; // Mode=0b11 (50MHz) et CNF=0b00 (Push-Pull) pour PB8 � PB15 (Leds 8 � 15)
	
}

/* Configuration Timer 1 ------------------------------------------------------------------*/
void cfgTimer1(void)
{
   

    RCC->APB2ENR |= (1 << 11);
    TIM1->PSC = 450; 
    TIM1->ARR = 64000; 
    TIM1->DIER |= UIE; 
    TIM1->CR1 |= 0x0001; 
	
    SETENA0 |= TIM1_UP_IRQChannel;
    
	
}

/* Traitement Interruption ------------------------------------------------------------------*/
void TIM1_UP_TIM10_IRQHandler (void)
{
    if(TIM1->SR & UIF)
    {
    LEDS_PORTB ^= (1<<8);
   	TIM1->SR &= ~UIF;
    }
}

/* Programme principal ------------------------------------------------------------------*/
int main(void)
{
  Enable_GPIO();
  Init_GPIO();
  cfgTimer1();   

  while(1)
  { }
}
