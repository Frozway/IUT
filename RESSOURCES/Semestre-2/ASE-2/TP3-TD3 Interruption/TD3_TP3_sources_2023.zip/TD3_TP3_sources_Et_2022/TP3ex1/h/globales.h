/**
  ******************************************************************************************************************
  * @file    globales.h 
  * @author  IUT Informatique La Rochelle
  * @version v1.1
  * @date    2021
  * @brief   d�clarations des variables globales
  ******************************************************************************************************************/


#ifndef __GLOBALES_H
#define __GLOBALES_H

volatile int xBoule;
volatile int yBoule;

#endif
