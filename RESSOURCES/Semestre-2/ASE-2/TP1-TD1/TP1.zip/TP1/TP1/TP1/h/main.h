// main.h
#ifndef __MAIN_H
	#define __MAIN_H

	#define JOY_DOWN	3
	#define JOY_UP	15
	#define JOY_RIGHT	13
	#define JOY_LEFT	14
	#define JOY_SELECT	7

	#define LED_15 15

	#define APPUYE 0x0000

	#define ALL_LED_ON 0xFF00
	#define ALL_LED_OFF 0x0000

#endif
