/*----------------------------------------------------------------------------
2)	Chenillard � double sens :
Ecrire un programme qui permettra de faire d�filer les LEDS du chenillard vers la droite lors d�une action (impulsion) sur le bouton JOY_DROITE
et vers la gauche apr�s une action sur JOY_GAUCHE. La vitesse de d�filement devra �tre de 2 LEDs/seconde.

 * *----------------------------------------------------------------------------*/

#include <stm32f10x.h>        // STM32F10x Library Definitions

#include "main.h"
