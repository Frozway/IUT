// main.h
#ifndef __MAIN_H
#define __MAIN_H
#define ALL_LED_ON 0xFF00
#endif