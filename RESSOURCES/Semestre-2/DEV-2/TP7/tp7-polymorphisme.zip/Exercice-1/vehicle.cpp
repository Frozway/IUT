#include "vehicle.h"


Vehicle::Vehicle(string brand, string model, string registrationPlate, int constructionYear, int hp)
{
    itsBrand = brand ;
    itsModel = model ;
    itsRegistrationPlate = registrationPlate ;
    itsConstructionYear = constructionYear ;
    itsHP = hp ;
}
