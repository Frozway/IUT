#ifndef INSURANCE_H
#define INSURANCE_H
#include "client.h"
#include "vehicle.h"
#include <iostream>
#include <map>
#include <vector>

using namespace std;


class Insurance
{
private:
    string itsName;
public:
    Insurance(string name);
    ~Insurance();
    void addContract(Client *client, Vehicle *vehicle);
    void removeContract(Client *client, Vehicle *vehicle);
    void displayContracts();
    void displayContractsClient(Client *client);
    map<Client *, vector<Vehicle*>> * itsVehicleContracts ;
};

#endif // INSURANCE_H
